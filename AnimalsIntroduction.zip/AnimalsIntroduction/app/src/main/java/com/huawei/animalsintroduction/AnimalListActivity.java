package com.huawei.animalsintroduction;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.widget.HorizontalScrollView;

public class AnimalListActivity extends AppCompatActivity {

    HorizontalScrollView horizontalScrollView;
    CardView cv1;
    CardView cv2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal_list);

        horizontalScrollView = findViewById(R.id.horizontalScrollView);
        cv1 = findViewById(R.id.view2);
        cv2 = findViewById(R.id.view5);
    }
}
